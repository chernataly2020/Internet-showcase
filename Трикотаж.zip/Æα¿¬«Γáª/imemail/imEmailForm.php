<?php
if(substr(basename($_SERVER['PHP_SELF']), 0, 11) == "imEmailForm") {
	include '../res/x5engine.php';
	$form = new ImForm();
	$form->setField('Ваше имя', $_POST['imObjectForm_5_1'], '', false);
	$form->setField('Адрес электронной почты', $_POST['imObjectForm_5_2'], '', false);
	$form->setField('Текст сообщения', $_POST['imObjectForm_5_3'], '', false);

	if(@$_POST['action'] != 'check_answer') {
		if(!isset($_POST['imJsCheck']) || $_POST['imJsCheck'] != 'jsactive' || (isset($_POST['imSpProt']) && $_POST['imSpProt'] != ""))
			die(imPrintJsError());
		$form->mailToOwner('example@mail.ru', 'example@mail.ru', '', '', false);
		$form->mailToCustomer('example@mail.ru', $_POST['imObjectForm_5_2'], '', 'Уважаемый клиент! 
Спасибо за внимание к нашему товару!

Наши менеджеры обязательно с Вами свяжутся.
', false);
		@header('Location: ../index.html');
		exit();
	} else {
		echo $form->checkAnswer(@$_POST['id'], @$_POST['answer']) ? 1 : 0;
	}
}

// End of file