var x5CartData = {
	// General Cart Settings
	'settings': {
		'indexpage': 'cart/index.html',
		'continue_shopping_page': 'http://tricotazh.ru/index.html',
		'vat': 0.21,
		'vattype': 'included', // included|excluded|none
		'currency': 'руб',
		'currency_id': 'RUB',
		'showShipmentFields': true,
		'cartCookie': 'x5CartProducts0mx5zgkcq7q6ds33',
		'formCookie': 'x5CartForm0mx5zgkcq7q6ds33',
		'currency_format': '#.###,@@[C]',
		'order_no_format': '[yy][mm][dd]-[A-Z][A-Z][0-9][0-9]',
		'formAutocomplete': true,
		'formValidation': 'tip',
		'remove_from_cart_icon': 'cart/images/cart-remove.png',
		'add_to_cart_icon': 'cart/images/cart-add.png',
		'minimumAmount': 0,
		'currencies': [{ "value": "ALL", "text": "Albania, Leke, Lek" }, { "value": "USD", "text": "United States of America, Dollars, $" }, { "value": "AFN", "text": "Afghanistan, Afghanis, ؋" }, { "value": "ARS", "text": "Argentina, Pesos, $" }, { "value": "AUD", "text": "Australia, Dollars, $" }, { "value": "BGN", "text": "Bulgarian, Lev, лв" }, { "value": "BRL", "text": "Brazil, Reais, R$" }, { "value": "GBP", "text": "United Kingdom, Pounds, £" }, { "value": "BND", "text": "Brunei Darussalam, Dollars, $" }, { "value": "CAD", "text": "Canada, Dollars, $" }, { "value": "CNY", "text": "China, Yuan Renminbi, ¥" }, { "value": "HRK", "text": "Croatia, Kuna, ₡" }, { "value": "CZK", "text": "Czech Republic, Koruny, Kč" }, { "value": "DKK", "text": "Denmark, Kroner, kr" }, { "value": "EGP", "text": "Egypt, Pounds, £" }, { "value": "EUR", "text": "Euro, €" }, { "value": "GTQ", "text": "Guatemala, Quetzales, Q" }, { "value": "HKD", "text": "Hong Kong, Dollars, $" }, { "value": "HUF", "text": "Hungary, Forint, Ft" }, { "value": "ISK", "text": "Iceland, Kronur, kr" }, { "value": "INR", "text": "India, Rupees, Rs" }, { "value": "IDR", "text": "Indonesia, Rupiahs, Rp" }, { "value": "IRR", "text": "Iran, Rials, ﷼" }, { "value": "ILS", "text": "Israel, New Shekels, ₪" }, { "value": "JPY", "text": "Japan, Yen, ¥" }, { "value": "KZT", "text": "Kazakhstan, Tenge, лв" }, { "value": "KPW", "text": "Korea (North), Won, ₩" }, { "value": "KRW", "text": "Korea (South), Won, ₩" }, { "value": "LVL", "text": "Latvia, Lati, Ls" }, { "value": "LTL", "text": "Lithuania, Litai, Lt" }, { "value": "MYR", "text": "Malaysia, Ringgits, RM" }, { "value": "MXN", "text": "Mexico, Pesos, $" }, { "value": "NZD", "text": "New Zealand, Dollars, $" }, { "value": "NOK", "text": "Norway, Kroner, kr" }, { "value": "OMR", "text": "Oman, Rials, ﷼" }, { "value": "PLN", "text": "Poland, Zlotych, zł" }, { "value": "QAR", "text": "Qatar, Rials, ﷼" }, { "value": "RON", "text": "Romania, New Lei, lei" }, { "value": "RUB", "text": "Russia, Rubles, руб" }, { "value": "SAR", "text": "Saudi Arabia, Riyals, ﷼" }, { "value": "RSD", "text": "Serbia, Dinars, Дин." }, { "value": "SGD", "text": "Singapore, Dollars, $" }, { "value": "ZAR", "text": "South Africa, Rand, R" }, { "value": "SEK", "text": "Sweden, Kronor, kr" }, { "value": "CHF", "text": "Switzerland, Francs, CHF" }, { "value": "TWD", "text": "Taiwan, New Dollars, NT$" }, { "value": "THB", "text": "Thailand, Baht, ฿" }, { "value": "TTD", "text": "Trinidad and Tobago, Dollars, TT$" }, { "value": "TRY", "text": "Turkey, Lira, ₺" }, { "value": "UAH", "text": "Ukraine, Hryvnia, ₴" }]
	},

	// Cart Products
	'products': {
		'132z6gy9': {
			'id': '132z6gy9',
			'id_user': 'Трикотажная футболка',
			'name': 'Трикотажная футболка',
			'category': 'v794r5s6',
			'description': 'Трикотажная футболка из мягкого трикотажа',
			'price': 247.9338843,
			'avail': 'available',
			'images': ['images/0-big.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'62n640pb': {
			'id': '62n640pb',
			'id_user': 'Трикотажное платье',
			'name': 'Трикотажное платье',
			'category': 'v794r5s6',
			'description': 'Стильное трикотажное платье',
			'price': 1115.7024793,
			'avail': 'available',
			'images': ['images/33.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'k1dfp951': {
			'id': 'k1dfp951',
			'id_user': 'Модное трикотажное платье',
			'name': 'Модное трикотажное платье',
			'category': 'v794r5s6',
			'description': 'Модное трикотажное платье с интересным рисунком',
			'price': 1157.0247934,
			'avail': 'lack',
			'images': ['images/f607cf3cd43d425d9566e8d859f7abff.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'lr297to8': {
			'id': 'lr297to8',
			'id_user': 'Молодежное трикотажное платье',
			'name': 'Молодежное трикотажное платье',
			'category': 'v794r5s6',
			'description': 'Молодежное трикотажное платье модного фасона',
			'price': 1239.6694215,
			'avail': 'lack',
			'discount': {
				'type': 'relative',
				'amount': 0.25
			},
			'quantityDiscounts': {
			},
			'images': ['images/p5.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'u8sv3uq5': {
			'id': 'u8sv3uq5',
			'id_user': 'Модное платье',
			'name': 'Модное платье',
			'category': 'v794r5s6',
			'description': 'Модное трикотажное платье',
			'price': 826.446281,
			'avail': 'available',
			'images': ['images/sviter.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'jw4g9o28': {
			'id': 'jw4g9o28',
			'id_user': 'Трикотажный топ',
			'name': 'Трикотажный топ',
			'category': 'v794r5s6',
			'description': 'Модный молодежный трикотажный топ',
			'price': 661.1570248,
			'avail': 'available',
			'images': ['images/top-s-ameriqansqoi-proimoi-model-1.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'3063w450': {
			'id': '3063w450',
			'id_user': 'Модное трикотажное платье на весну',
			'name': 'Модное трикотажное платье на весну',
			'category': 'v794r5s6',
			'description': 'Модное трикотажное платье',
			'price': 1487.6033058,
			'avail': 'available',
			'images': ['images/trikotagnieplatia.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'oqt870yh': {
			'id': 'oqt870yh',
			'id_user': 'Трикотажное платье футляр',
			'name': 'Трикотажное платье футляр',
			'category': 'v794r5s6',
			'description': 'Модное трикотажное платье футляр',
			'price': 1322.3140496,
			'avail': 'available',
			'images': ['images/userFiles-internal-img-core380photo1.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'q85zelc7': {
			'id': 'q85zelc7',
			'id_user': 'Трикотажная футболка для мужчин',
			'name': 'Трикотажная футболка для мужчин',
			'category': 'r43xpcn5',
			'description': 'Трикотажная футболка для мужчин',
			'price': 247.9338843,
			'avail': 'available',
			'images': ['images/1m.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'bdvtwv9p': {
			'id': 'bdvtwv9p',
			'id_user': 'Трикотажный жакет',
			'name': 'Трикотажный жакет',
			'category': 'r43xpcn5',
			'description': 'Мужской трикотажный жакет',
			'price': 413.2231405,
			'avail': 'available',
			'images': ['images/2319.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'7td8hi13': {
			'id': '7td8hi13',
			'id_user': 'Мужской  трикотажный джемпер',
			'name': 'Мужской  трикотажный джемпер',
			'category': 'r43xpcn5',
			'description': 'Мужской  трикотажный джемпер',
			'price': 495.8677686,
			'avail': 'available',
			'images': ['images/7206.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'120k772i': {
			'id': '120k772i',
			'id_user': 'Модная трикотажная футболка',
			'name': 'Модная трикотажная футболка',
			'category': 'r43xpcn5',
			'description': 'Модная трикотажная футболка для мужчин',
			'price': 578.5123967,
			'avail': 'available',
			'images': ['images/8495.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'oc2xt7mu': {
			'id': 'oc2xt7mu',
			'id_user': 'Трикотажная молодежная футболка',
			'name': 'Трикотажная молодежная футболка',
			'category': 'r43xpcn5',
			'description': 'Трикотажная молодежная футболка',
			'price': 743.8016529,
			'avail': 'lack',
			'discount': {
				'type': 'relative',
				'amount': 0.1
			},
			'images': ['images/8516.jpg', 'images/8507.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'3336796m': {
			'id': '3336796m',
			'id_user': 'Джемпер из трикотажа для мужчин',
			'name': 'Джемпер из трикотажа для мужчин',
			'category': 'r43xpcn5',
			'description': 'Джемпер из трикотажа для мужчин',
			'price': 743.8016529,
			'avail': 'available',
			'images': ['images/9904.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'4jr17iif': {
			'id': '4jr17iif',
			'id_user': 'Трикотажный жакет для мужчин',
			'name': 'Трикотажный жакет для мужчин',
			'category': 'r43xpcn5',
			'description': 'Трикотажный жакет',
			'price': 247.9338843,
			'avail': 'available',
			'images': ['images/vest-male-maglia-ru.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'3wmdmhwi': {
			'id': '3wmdmhwi',
			'id_user': 'Шапочка-шлем',
			'name': 'Шапочка-шлем',
			'category': 'j3lwpo6m',
			'description': 'Трикотажная шапочка-шлем с рисунком',
			'price': 165.2892562,
			'avail': 'available',
			'images': ['images/86b486072b75ef685331f8ca81a311f6.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'5pvfs4hn': {
			'id': '5pvfs4hn',
			'id_user': 'Шапочка-шлем с рисунком для маленьких',
			'name': 'Шапочка-шлем с рисунком для маленьких',
			'category': 'j3lwpo6m',
			'description': 'Шапочка-шлем с рисунком для маленьких',
			'price': 165.2892562,
			'avail': 'available',
			'images': ['images/19847241.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'95g9glvr': {
			'id': '95g9glvr',
			'id_user': 'Трикотажное платье для девочки',
			'name': 'Трикотажное платье для девочки',
			'category': 'j3lwpo6m',
			'description': 'Трикотажное платье для девочки',
			'price': 247.9338843,
			'avail': 'available',
			'images': ['images/14730b.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'6nuq8159': {
			'id': '6nuq8159',
			'id_user': 'Детский костюмчик',
			'name': 'Детский костюмчик',
			'category': 'j3lwpo6m',
			'description': 'Детский костюмчик для самых маленьких',
			'price': 247.9338843,
			'avail': 'available',
			'images': ['images/9484170.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'b8k60myd': {
			'id': 'b8k60myd',
			'id_user': 'Детский костюмчик для малышей',
			'name': 'Детский костюмчик для малышей',
			'category': 'j3lwpo6m',
			'description': 'Детский костюмчик для малышей',
			'price': 247.9338843,
			'avail': 'available',
			'images': ['images/18838912094e3d8f601b867.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'328sg1rj': {
			'id': '328sg1rj',
			'id_user': 'Трикотажная кофточка для девочки',
			'name': 'Трикотажная кофточка для девочки',
			'category': 'j3lwpo6m',
			'description': 'Трикотажная кофточка для девочки',
			'price': 206.6115702,
			'avail': 'available',
			'images': ['images/c8c20d93-2a10-11e1-a0a3-e0cb4ec2a3e3_1_bbb32f9d-3b63-11e1-9f43-e0cb4ec2a3e3.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'klsh6pv3': {
			'id': 'klsh6pv3',
			'id_user': 'Трикотажное платьице для маленькой девочки',
			'name': 'Трикотажное платьице для маленькой девочки',
			'category': 'j3lwpo6m',
			'description': '',
			'price': 247.9338843,
			'avail': 'available',
			'images': ['images/img_2f4f656647_base.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'5yj849d8': {
			'id': '5yj849d8',
			'id_user': 'Костюмчики для малышей',
			'name': 'Костюмчики для малышей',
			'category': 'j3lwpo6m',
			'description': 'Костюмчики для малышей',
			'price': 247.9338843,
			'avail': 'available',
			'images': ['images/kombinezonchik-applikatsiey.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'8f74ukzf': {
			'id': '8f74ukzf',
			'id_user': 'Спортивная трикотажная кофта',
			'name': 'Спортивная трикотажная кофта',
			'category': '1471pt67',
			'description': 'Спортивная трикотажная кофта',
			'price': 371.9008264,
			'avail': 'available',
			'discount': {
				'type': 'relative',
				'amount': 0.25
			},
			'images': ['images/9e94024882--odezhda-sportivnaya-kofta-na-molnii.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'03v3n4p6': {
			'id': '03v3n4p6',
			'id_user': 'Спортивная трикотажная шапочка',
			'name': 'Спортивная трикотажная шапочка',
			'category': '1471pt67',
			'description': 'Спортивная трикотажная шапочка',
			'price': 0,
			'avail': 'lack',
			'images': ['images/1393328445.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'z74r7gyu': {
			'id': 'z74r7gyu',
			'id_user': 'Женская спортивная кофта с капюшоном',
			'name': 'Женская спортивная кофта с капюшоном',
			'category': '1471pt67',
			'description': 'Удобная женская спортивная кофта с капюшоном',
			'price': 495.8677686,
			'avail': 'lack',
			'images': ['images/img_0598-222.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'55x7ofbt': {
			'id': '55x7ofbt',
			'id_user': 'Женская трикотажная спортивная кофта с рисунком',
			'name': 'Женская трикотажная спортивная кофта с рисунком',
			'category': '1471pt67',
			'description': 'Женская трикотажная спортивная кофта с рисунком',
			'price': 661.1570248,
			'avail': 'available',
			'images': ['images/img_5837.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'6m967103': {
			'id': '6m967103',
			'id_user': 'Спортивная кофта из трикотажа с модным принтом',
			'name': 'Спортивная кофта из трикотажа с модным принтом',
			'category': '1471pt67',
			'description': 'Спортивная кофта из трикотажа с модным принтом',
			'price': 743.8016529,
			'avail': 'available',
			'images': ['images/n33XA38G06Q.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'y3lnkxxu': {
			'id': 'y3lnkxxu',
			'id_user': 'Мужская трикотажная спортивная кофта',
			'name': 'Мужская трикотажная спортивная кофта',
			'category': '1471pt67',
			'description': 'Мужская трикотажная спортивная кофта',
			'price': 826.446281,
			'avail': 'available',
			'images': ['images/nike8.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'8b3f60h5': {
			'id': '8b3f60h5',
			'id_user': 'Трикотажный спортивный костюм',
			'name': 'Трикотажный спортивный костюм',
			'category': '1471pt67',
			'description': 'Трикотажный спортивный костюм',
			'price': 826.446281,
			'avail': 'available',
			'images': ['images/pic1_23122010231627.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'skenqnwr': {
			'id': 'skenqnwr',
			'id_user': 'Женская трикотажная спортивная кофта',
			'name': 'Женская трикотажная спортивная кофта',
			'category': '1471pt67',
			'description': 'Женская трикотажная спортивная кофта',
			'price': 661.1570248,
			'avail': 'lack',
			'images': ['images/plate-iz-trikotaja-vesna-2014.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'856i1ihp': {
			'id': '856i1ihp',
			'id_user': 'Трикотажный спортивный костюм для мужчин',
			'name': 'Трикотажный спортивный костюм для мужчин',
			'category': '1471pt67',
			'description': 'Трикотажный спортивный костюм для мужчин',
			'price': 909.0909091,
			'avail': 'available',
			'discount': {
				'type': 'relative',
				'amount': 0.25
			},
			'images': ['images/T2BoNCXnVNXXXXXXXX_--761129123.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'1kb99cu5': {
			'id': '1kb99cu5',
			'id_user': 'Нательное трикотажное белье для мужчин',
			'name': 'Нательное трикотажное белье для мужчин',
			'category': 'fojk099n',
			'description': 'Нательное трикотажное белье для мужчин',
			'price': 743.8016529,
			'avail': 'available',
			'images': ['images/110147.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'rrk5143g': {
			'id': 'rrk5143g',
			'id_user': 'Трикотажная футболка защитного цвета',
			'name': 'Трикотажная футболка защитного цвета',
			'category': 'fojk099n',
			'description': '',
			'price': 330.5785124,
			'avail': 'lack',
			'images': ['images/14630594_w640_h640_otazhnaya_kamuflirovannaya.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'724sjvm1': {
			'id': '724sjvm1',
			'id_user': 'Трикотажный костюм для мужчин',
			'name': 'Трикотажный костюм для мужчин',
			'category': 'fojk099n',
			'description': '',
			'price': 661.1570248,
			'avail': 'available',
			'images': ['images/1171404927.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		},
		'rzu6p3f2': {
			'id': 'rzu6p3f2',
			'id_user': 'Нательный костюм для мужчин из трикотажа',
			'name': 'Нательный костюм для мужчин из трикотажа',
			'category': 'fojk099n',
			'description': 'Нательный костюм для мужчин из трикотажа',
			'price': 735.5371901,
			'avail': 'unknown',
			'discount': {
				'type': 'relative',
				'amount': 0.1
			},
			'images': ['images/woolly_b.jpg', 'images/belie_natelnoe_s_nachesom.thumb.jpg'],
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'weight': 0
		}
	},

	// Shipping Data
	'shippings': {
		'j48dn4la': {
			'id': 'j48dn4la',
			'name': 'почтой',
			'description': 'Товары будут доставлены в течение 3-5 дней.',
			'vat': 0.21,
			'type': 'FIXED',
			'price': 4.1322314,
			'email': 'Доставка почтой.<br />Товары будут доставлены в течение 3-5 дней.'
		},
		'hdj47dut': {
			'id': 'hdj47dut',
			'name': 'службой экспресс-доставки',
			'description': 'Товары будут доставлены в течение 1-2 дней.',
			'vat': 0.21,
			'type': 'FIXED',
			'price': 8.2644628,
			'email': 'Доставка службой экспресс-доставки.<br />Товары будут доставлены в течение 1-2 дней.'
		}
	},

	// Payment Data
	'payments': {
		'8dkejfu5': {
			'id': '8dkejfu5',
			'name': 'Банковский платеж',
			'description': 'Оплатить позже банковским платежом.',
			'email': 'Вот данные, необходимые для банковского платежа:<br /><br />XXX YYY ZZZ<br /><br />Пожалуйста, обратите внимание, что как только платеж будет проведен, необходимо отправить копию квитанции об оплате вместе с номером заказа.',
			'vattype': 'included', // included|excluded|none
			'vat': 0.21,
			'pricetype': 'fixed',
			'price': 0
		}
	},

	// User's data form and agreement text
	'form': {
		'agreement': '',
		'acceptAgreement': true,
		'fields': [
			{
				'id': 'Name',
				'name': 'Имя',
				'value': '',
				'type': 'Text',
				'mandatory': true,
				'filter': 'mandatory',
				'shipping': true,
				'custom': false
			},
			{
				'id': 'LastName',
				'name': 'Фамилия',
				'value': '',
				'type': 'Text',
				'mandatory': true,
				'filter': 'mandatory',
				'shipping': true,
				'custom': false
			},
			{
				'id': 'Address1',
				'name': 'Адрес',
				'value': '',
				'type': 'Text',
				'mandatory': true,
				'filter': 'mandatory',
				'shipping': true,
				'custom': false
			},
			{
				'id': 'ZipPostalCode',
				'name': 'Почтовый индекс',
				'value': '',
				'type': 'Text',
				'mandatory': true,
				'filter': 'mandatory',
				'shipping': true,
				'custom': false
			},
			{
				'id': 'City',
				'name': 'Город',
				'value': '',
				'type': 'Text',
				'mandatory': true,
				'filter': 'mandatory',
				'shipping': true,
				'custom': false
			},
			{
				'id': 'StateRegion',
				'name': 'Область',
				'value': '',
				'type': 'Text',
				'mandatory': true,
				'filter': 'mandatory',
				'shipping': true,
				'custom': false
			},
			{
				'id': 'Phone',
				'name': 'Телефон',
				'value': '',
				'type': 'Text',
				'mandatory': false,
				'filter': 'valGenTelephone',
				'shipping': true,
				'custom': false
			},
			{
				'id': 'Email',
				'name': 'Адрес e-mail',
				'value': '',
				'type': 'Text',
				'mandatory': true,
				'filter': 'mandatory valEmail',
				'shipping': false,
				'custom': false
			},
			{
				'id': 'Note',
				'name': 'Примечание',
				'value': '',
				'type': 'TextArea',
				'mandatory': false,
				'filter': '',
				'shipping': false,
				'custom': true
			}
		]
	}
};
x5engine.boot.push('x5engine.cart.manager = new x5engine.cart.ecommerce(x5CartData)');

// End of file x5cart.js