<?php
	$oNameList = array("tx7","lpz","lfa","ydv","zdx","agg","3v6","kyu","v3p","2sp");
	$oCharList = array("V","F","7","G","L","M","H","F","A","P");
// End of file imkeys.php