<?php require_once("res/x5engine.php"); ?><!DOCTYPE html><!-- HTML5 -->
<html lang="ru-RU" dir="ltr">
	<head>
		<title>Поиск - ЗАО Трубчевский трикотаж</title>
		<meta charset="utf-8" />
		<!--[if IE]><meta http-equiv="ImageToolbar" content="False" /><![endif]-->
		<meta name="generator" content="Incomedia WebSite X5 Professional 11.0.2.13 - www.websitex5.com" />
		<meta name="viewport" content="width=980" />
		<link rel="stylesheet" type="text/css" href="style/reset.css" media="screen,print" />
		<link rel="stylesheet" type="text/css" href="style/print.css" media="print" />
		<link rel="stylesheet" type="text/css" href="style/style.css" media="screen,print" />
		<link rel="stylesheet" type="text/css" href="style/template.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="style/menu.css" media="screen" />
		<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="style/ie.css" media="screen" /><![endif]-->
		
		<script type="text/javascript" src="res/jquery.js?13"></script>
		<script type="text/javascript" src="res/x5engine.js?13"></script>
		
	</head>
	<body>
		<div id="imHeaderBg"></div>
		<div id="imFooterBg"></div>
		<div id="imPage">
			<div id="imHeader">
				<h1 class="imHidden">Поиск - ЗАО Трубчевский трикотаж</h1>
				
				<div id="imSlideshowContent_0" style="position: absolute; top: 13px; left: 387px; width: 590px; height: 238px;"><div id="imFlashContainer_0"></div></div><script type="text/javascript">var imTemplateSlideShow_0_settings = {'target': '#imSlideshowContent_0', 'width': 590, 'height': 238, 'autoplay': true, 'random': false, 'thumbsPosition': 'none', 'disableTouch': true, 'loadingImage': 'res/imLoad.gif', 'showButtons': false, 'backgroundColor': 'transparent', 'bullets': {'show': true,'url': 'gallery/bullets.png','size': 22,'distanceTop': 5,'distanceBottom': 5,'distanceLeft': 5,'distanceRight': 5,'positionY': 'bottom','positionX': 'center'},'media': [{'width': 590,'height': 238,'type': 'image','url': 'gallery/slide-4.jpg','autoplayTime': 5000,'effect': 'horizontalSlide'},{'width': 590,'height': 238,'type': 'image','url': 'gallery/slide-2.jpg','autoplayTime': 5000,'effect': 'horizontalSlide'}]}; x5engine.boot.push('x5engine.gallery(imTemplateSlideShow_0_settings)');</script>
				<div style="position: absolute; top: 203px; left: 72px; width: 698px; height: 58px;"><img src="images/header_text.png" alt="ЗАО &quot;Трубчевский трикотаж&quot;" style="width: 698px; height: 58px;" /></div>
			</div>
			<a class="imHidden" href="#imGoToCont" title="Заголовок главного меню">Перейти к контенту</a>
			<a id="imGoToMenu"></a><p class="imHidden">Главное меню:</p>
			<div id="imMnMn" class="auto">
				<ul class="auto">
					<li id="imMnMnNode0">
						<a href="index.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>Главная страница</span>
							</span>
						</a>
					</li><li id="imMnMnNode12">
						<span class="imMnMnFirstBg">
							<span class="imMnMnTxt"><span class="imMnMnImg"></span>О компании<span class="imMnMnLevelImg"></span></span>
						</span>
						<ul class="auto">
							<li id="imMnMnNode13" class="imMnMnFirst">
								<a href="history.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>История фабрики</span>
									</span>
								</a>
							</li><li id="imMnMnNode14" class="imMnMnMiddle">
								<a href="proizvodstvo.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Производство</span>
									</span>
								</a>
							</li><li id="imMnMnNode15" class="imMnMnMiddle">
								<a href="sheff.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Руководство</span>
									</span>
								</a>
							</li><li id="imMnMnNode16" class="imMnMnLast">
								<a href="work.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Вакансии</span>
									</span>
								</a>
							</li>
						</ul>
					</li><li id="imMnMnNode17">
						<span class="imMnMnFirstBg">
							<span class="imMnMnTxt"><span class="imMnMnImg"></span>Услуги<span class="imMnMnLevelImg"></span></span>
						</span>
						<ul class="auto">
							<li id="imMnMnNode19" class="imMnMnFirst">
								<a href="clothes-children.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Пошив детской одежды</span>
									</span>
								</a>
							</li><li id="imMnMnNode18" class="imMnMnMiddle">
								<a href="clothes-woman.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Пошив женской одежды</span>
									</span>
								</a>
							</li><li id="imMnMnNode22" class="imMnMnMiddle">
								<a href="clothes-man.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Пошив мужской одежды</span>
									</span>
								</a>
							</li><li id="imMnMnNode20" class="imMnMnMiddle">
								<a href="clothes-sport.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Пошив спортивной одежды</span>
									</span>
								</a>
							</li><li id="imMnMnNode21" class="imMnMnLast">
								<a href="clothes-trikotazh.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Пошив трикотажных изделий</span>
									</span>
								</a>
							</li>
						</ul>
					</li><li id="imMnMnNode6">
						<span class="imMnMnFirstBg">
							<span class="imMnMnTxt"><span class="imMnMnImg"></span>Ассортимент продукции<span class="imMnMnLevelImg"></span></span>
						</span>
						<ul class="auto">
							<li id="imMnMnNode7" class="imMnMnFirst">
								<a href="children.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Детская одежда</span>
									</span>
								</a>
							</li><li id="imMnMnNode8" class="imMnMnMiddle">
								<a href="woman.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Женская одежда</span>
									</span>
								</a>
							</li><li id="imMnMnNode9" class="imMnMnMiddle">
								<a href="man.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Мужская одежда</span>
									</span>
								</a>
							</li><li id="imMnMnNode11" class="imMnMnMiddle">
								<a href="sport.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Спортивная одежда</span>
									</span>
								</a>
							</li><li id="imMnMnNode10" class="imMnMnLast">
								<a href="body.html">
									<span class="imMnMnBorder">
										<span class="imMnMnTxt"><span class="imMnMnImg"></span>Нательная одежда</span>
									</span>
								</a>
							</li>
						</ul>
					</li><li id="imMnMnNode23">
						<a href="sotrud.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>Условия сотрудничества</span>
							</span>
						</a>
					</li><li id="imMnMnNode24">
						<a href="news.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>Новости</span>
							</span>
						</a>
					</li><li id="imMnMnNode5">
						<a href="contacts.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>Контакты</span>
							</span>
						</a>
					</li>
				</ul>
			</div>
			<div id="imContentGraphics"></div>
			<div id="imContent">
				<a id="imGoToCont"></a>
				<h2 id="imPgTitle">Резуьтаты поиска</h2><?php
$search = new imSearch();
$keys = isset($_GET['search']) ? $_GET['search'] : "";
$page = isset($_GET['page']) ? $_GET['page'] : 0;
$type = isset($_GET['type']) ? $_GET['type'] : "pages"; ?>
<div class="searchPageContainer">
<?php echo $search->search($keys, $page, $type); ?>
</div>
				  
				<div class="imClear"></div>
			</div>
			<div id="imFooter">
				
			</div>
		</div>
		<span class="imHidden"><a href="#imGoToCont" title="Прочесть эту страницу заново">Назад к содержимому</a> | <a href="#imGoToMenu" title="Прочесть этот сайт заново">Назад к главному меню</a></span>
		<script type="text/javascript" src="cart/x5cart.js?13_635591353582656250"></script>

		<noscript class="imNoScript"><div class="alert alert-red">Чтобы использовать этот сайт, необходимо включить JavaScript</div></noscript>
	</body>
</html>
