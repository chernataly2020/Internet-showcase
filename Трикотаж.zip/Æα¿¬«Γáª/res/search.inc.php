<?php

/*****************
	GENERAL SETTINGS
*****************/
$imSettings['search']['general'] = array(
	'menu_position' => 'left',
	'defaultScope' => array(
		'0' => 'index.html',
		'5' => 'contacts.html',
		'7' => 'children.html',
		'8' => 'woman.html',
		'9' => 'man.html',
		'10' => 'body.html',
		'11' => 'sport.html',
		'13' => 'history.html',
		'14' => 'proizvodstvo.html',
		'15' => 'sheff.html',
		'16' => 'work.html',
		'18' => 'clothes-woman.html',
		'19' => 'clothes-children.html',
		'20' => 'clothes-sport.html',
		'21' => 'clothes-trikotazh.html',
		'22' => 'clothes-man.html',
		'23' => 'sotrud.html',
		'24' => 'news.html'
	),
	'extendedScope' => array(
	)
);

/*****************
	PRODUCTS SEARCH
*****************/
$imSettings['search']['products'] = array(
	'132z6gy9' => array(
		'name' => 'Трикотажная футболка',
		'description' => 'Трикотажная футболка из мягкого трикотажа',
		'image' => '<img src="images/0-big.jpg" alt="Трикотажная футболка" title="Трикотажная футболка" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/0-big.jpg\', width: 600, height: 765, description: \'Трикотажная футболка из мягкого трикотажа\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '300,00 руб'
	),
	'62n640pb' => array(
		'name' => 'Трикотажное платье',
		'description' => 'Стильное трикотажное платье',
		'image' => '<img src="images/33.jpg" alt="Трикотажное платье" title="Трикотажное платье" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/33.jpg\', width: 333, height: 500, description: \'Стильное трикотажное платье\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.350,00 руб'
	),
	'k1dfp951' => array(
		'name' => 'Модное трикотажное платье',
		'description' => 'Модное трикотажное платье с интересным рисунком',
		'image' => '<img src="images/f607cf3cd43d425d9566e8d859f7abff.jpg" alt="Модное трикотажное платье" title="Модное трикотажное платье" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/f607cf3cd43d425d9566e8d859f7abff.jpg\', width: 600, height: 600, description: \'Модное трикотажное платье с интересным рисунком\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.400,00 руб'
	),
	'lr297to8' => array(
		'name' => 'Молодежное трикотажное платье',
		'description' => 'Молодежное трикотажное платье модного фасона',
		'image' => '<img src="images/p5.jpg" alt="Молодежное трикотажное платье" title="Молодежное трикотажное платье" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/p5.jpg\', width: 300, height: 493, description: \'Молодежное трикотажное платье модного фасона\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.500,00 руб'
	),
	'u8sv3uq5' => array(
		'name' => 'Модное платье',
		'description' => 'Модное трикотажное платье',
		'image' => '<img src="images/sviter.jpg" alt="Модное платье" title="Модное платье" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/sviter.jpg\', width: 320, height: 481, description: \'Модное трикотажное платье\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.000,00 руб'
	),
	'jw4g9o28' => array(
		'name' => 'Трикотажный топ',
		'description' => 'Модный молодежный трикотажный топ',
		'image' => '<img src="images/top-s-ameriqansqoi-proimoi-model-1.jpg" alt="Трикотажный топ" title="Трикотажный топ" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/top-s-ameriqansqoi-proimoi-model-1.jpg\', width: 337, height: 516, description: \'Модный молодежный трикотажный топ\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '800,00 руб'
	),
	'3063w450' => array(
		'name' => 'Модное трикотажное платье на весну',
		'description' => 'Модное трикотажное платье',
		'image' => '<img src="images/trikotagnieplatia.jpg" alt="Модное трикотажное платье на весну" title="Модное трикотажное платье на весну" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/trikotagnieplatia.jpg\', width: 424, height: 572, description: \'Модное трикотажное платье\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.800,00 руб'
	),
	'oqt870yh' => array(
		'name' => 'Трикотажное платье футляр',
		'description' => 'Модное трикотажное платье футляр',
		'image' => '<img src="images/userFiles-internal-img-core380photo1.jpg" alt="Трикотажное платье футляр" title="Трикотажное платье футляр" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/userFiles-internal-img-core380photo1.jpg\', width: 533, height: 800, description: \'Модное трикотажное платье футляр\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.600,00 руб'
	),
	'q85zelc7' => array(
		'name' => 'Трикотажная футболка для мужчин',
		'description' => 'Трикотажная футболка для мужчин',
		'image' => '<img src="images/1m.jpg" alt="Трикотажная футболка для мужчин" title="Трикотажная футболка для мужчин" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/1m.jpg\', width: 600, height: 714, description: \'Трикотажная футболка для мужчин\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '300,00 руб'
	),
	'bdvtwv9p' => array(
		'name' => 'Трикотажный жакет',
		'description' => 'Мужской трикотажный жакет',
		'image' => '<img src="images/2319.jpg" alt="Трикотажный жакет" title="Трикотажный жакет" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/2319.jpg\', width: 533, height: 800, description: \'Мужской трикотажный жакет\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '500,00 руб'
	),
	'7td8hi13' => array(
		'name' => 'Мужской  трикотажный джемпер',
		'description' => 'Мужской  трикотажный джемпер',
		'image' => '<img src="images/7206.jpg" alt="Мужской  трикотажный джемпер" title="Мужской  трикотажный джемпер" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/7206.jpg\', width: 533, height: 800, description: \'Мужской  трикотажный джемпер\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '600,00 руб'
	),
	'120k772i' => array(
		'name' => 'Модная трикотажная футболка',
		'description' => 'Модная трикотажная футболка для мужчин',
		'image' => '<img src="images/8495.jpg" alt="Модная трикотажная футболка" title="Модная трикотажная футболка" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/8495.jpg\', width: 533, height: 800, description: \'Модная трикотажная футболка для мужчин\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '700,00 руб'
	),
	'oc2xt7mu' => array(
		'name' => 'Трикотажная молодежная футболка',
		'description' => 'Трикотажная молодежная футболка',
		'image' => '<img src="images/8516.jpg" alt="Трикотажная молодежная футболка" title="Трикотажная молодежная футболка" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/8516.jpg\', width: 533, height: 800, description: \'Трикотажная молодежная футболка\' }, { type: \'image\', url: \'images/8507.jpg\', width: 533, height: 800, description: \'Трикотажная молодежная футболка\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '900,00 руб'
	),
	'3336796m' => array(
		'name' => 'Джемпер из трикотажа для мужчин',
		'description' => 'Джемпер из трикотажа для мужчин',
		'image' => '<img src="images/9904.jpg" alt="Джемпер из трикотажа для мужчин" title="Джемпер из трикотажа для мужчин" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/9904.jpg\', width: 533, height: 800, description: \'Джемпер из трикотажа для мужчин\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '900,00 руб'
	),
	'4jr17iif' => array(
		'name' => 'Трикотажный жакет для мужчин',
		'description' => 'Трикотажный жакет',
		'image' => '<img src="images/vest-male-maglia-ru.jpg" alt="Трикотажный жакет для мужчин" title="Трикотажный жакет для мужчин" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/vest-male-maglia-ru.jpg\', width: 533, height: 800, description: \'Трикотажный жакет\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '300,00 руб'
	),
	'3wmdmhwi' => array(
		'name' => 'Шапочка-шлем',
		'description' => 'Трикотажная шапочка-шлем с рисунком',
		'image' => '<img src="images/86b486072b75ef685331f8ca81a311f6.jpg" alt="Шапочка-шлем" title="Шапочка-шлем" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/86b486072b75ef685331f8ca81a311f6.jpg\', width: 571, height: 800, description: \'Трикотажная шапочка-шлем с рисунком\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '200,00 руб'
	),
	'5pvfs4hn' => array(
		'name' => 'Шапочка-шлем с рисунком для маленьких',
		'description' => 'Шапочка-шлем с рисунком для маленьких',
		'image' => '<img src="images/19847241.jpg" alt="Шапочка-шлем с рисунком для маленьких" title="Шапочка-шлем с рисунком для маленьких" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/19847241.jpg\', width: 532, height: 800, description: \'Шапочка-шлем с рисунком для маленьких\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '200,00 руб'
	),
	'95g9glvr' => array(
		'name' => 'Трикотажное платье для девочки',
		'description' => 'Трикотажное платье для девочки',
		'image' => '<img src="images/14730b.jpg" alt="Трикотажное платье для девочки" title="Трикотажное платье для девочки" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/14730b.jpg\', width: 545, height: 730, description: \'Трикотажное платье для девочки\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '300,00 руб'
	),
	'6nuq8159' => array(
		'name' => 'Детский костюмчик',
		'description' => 'Детский костюмчик для самых маленьких',
		'image' => '<img src="images/9484170.jpg" alt="Детский костюмчик" title="Детский костюмчик" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/9484170.jpg\', width: 397, height: 348, description: \'Детский костюмчик для самых маленьких\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '300,00 руб'
	),
	'b8k60myd' => array(
		'name' => 'Детский костюмчик для малышей',
		'description' => 'Детский костюмчик для малышей',
		'image' => '<img src="images/18838912094e3d8f601b867.jpg" alt="Детский костюмчик для малышей" title="Детский костюмчик для малышей" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/18838912094e3d8f601b867.jpg\', width: 257, height: 352, description: \'Детский костюмчик для малышей\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '300,00 руб'
	),
	'328sg1rj' => array(
		'name' => 'Трикотажная кофточка для девочки',
		'description' => 'Трикотажная кофточка для девочки',
		'image' => '<img src="images/c8c20d93-2a10-11e1-a0a3-e0cb4ec2a3e3_1_bbb32f9d-3b63-11e1-9f43-e0cb4ec2a3e3.jpg" alt="Трикотажная кофточка для девочки" title="Трикотажная кофточка для девочки" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/c8c20d93-2a10-11e1-a0a3-e0cb4ec2a3e3_1_bbb32f9d-3b63-11e1-9f43-e0cb4ec2a3e3.jpg\', width: 532, height: 800, description: \'Трикотажная кофточка для девочки\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '250,00 руб'
	),
	'klsh6pv3' => array(
		'name' => 'Трикотажное платьице для маленькой девочки',
		'description' => '',
		'image' => '<img src="images/img_2f4f656647_base.jpg" alt="Трикотажное платьице для маленькой девочки" title="Трикотажное платьице для маленькой девочки" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/img_2f4f656647_base.jpg\', width: 500, height: 500, description: \'\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '300,00 руб'
	),
	'5yj849d8' => array(
		'name' => 'Костюмчики для малышей',
		'description' => 'Костюмчики для малышей',
		'image' => '<img src="images/kombinezonchik-applikatsiey.jpg" alt="Костюмчики для малышей" title="Костюмчики для малышей" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/kombinezonchik-applikatsiey.jpg\', width: 460, height: 300, description: \'Костюмчики для малышей\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '300,00 руб'
	),
	'8f74ukzf' => array(
		'name' => 'Спортивная трикотажная кофта',
		'description' => 'Спортивная трикотажная кофта',
		'image' => '<img src="images/9e94024882--odezhda-sportivnaya-kofta-na-molnii.jpg" alt="Спортивная трикотажная кофта" title="Спортивная трикотажная кофта" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/9e94024882--odezhda-sportivnaya-kofta-na-molnii.jpg\', width: 432, height: 768, description: \'Спортивная трикотажная кофта\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '450,00 руб'
	),
	'03v3n4p6' => array(
		'name' => 'Спортивная трикотажная шапочка',
		'description' => 'Спортивная трикотажная шапочка',
		'image' => '<img src="images/1393328445.jpg" alt="Спортивная трикотажная шапочка" title="Спортивная трикотажная шапочка" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/1393328445.jpg\', width: 478, height: 450, description: \'Спортивная трикотажная шапочка\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '0,00 руб'
	),
	'z74r7gyu' => array(
		'name' => 'Женская спортивная кофта с капюшоном',
		'description' => 'Удобная женская спортивная кофта с капюшоном',
		'image' => '<img src="images/img_0598-222.jpg" alt="Женская спортивная кофта с капюшоном" title="Женская спортивная кофта с капюшоном" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/img_0598-222.jpg\', width: 520, height: 800, description: \'Удобная женская спортивная кофта с капюшоном\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '600,00 руб'
	),
	'55x7ofbt' => array(
		'name' => 'Женская трикотажная спортивная кофта с рисунком',
		'description' => 'Женская трикотажная спортивная кофта с рисунком',
		'image' => '<img src="images/img_5837.jpg" alt="Женская трикотажная спортивная кофта с рисунком" title="Женская трикотажная спортивная кофта с рисунком" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/img_5837.jpg\', width: 537, height: 800, description: \'Женская трикотажная спортивная кофта с рисунком\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '800,00 руб'
	),
	'6m967103' => array(
		'name' => 'Спортивная кофта из трикотажа с модным принтом',
		'description' => 'Спортивная кофта из трикотажа с модным принтом',
		'image' => '<img src="images/n33XA38G06Q.jpg" alt="Спортивная кофта из трикотажа с модным принтом" title="Спортивная кофта из трикотажа с модным принтом" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/n33XA38G06Q.jpg\', width: 219, height: 300, description: \'Спортивная кофта из трикотажа с модным принтом\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '900,00 руб'
	),
	'y3lnkxxu' => array(
		'name' => 'Мужская трикотажная спортивная кофта',
		'description' => 'Мужская трикотажная спортивная кофта',
		'image' => '<img src="images/nike8.jpg" alt="Мужская трикотажная спортивная кофта" title="Мужская трикотажная спортивная кофта" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/nike8.jpg\', width: 480, height: 640, description: \'Мужская трикотажная спортивная кофта\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.000,00 руб'
	),
	'8b3f60h5' => array(
		'name' => 'Трикотажный спортивный костюм',
		'description' => 'Трикотажный спортивный костюм',
		'image' => '<img src="images/pic1_23122010231627.jpg" alt="Трикотажный спортивный костюм" title="Трикотажный спортивный костюм" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/pic1_23122010231627.jpg\', width: 600, height: 400, description: \'Трикотажный спортивный костюм\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.000,00 руб'
	),
	'skenqnwr' => array(
		'name' => 'Женская трикотажная спортивная кофта',
		'description' => 'Женская трикотажная спортивная кофта',
		'image' => '<img src="images/plate-iz-trikotaja-vesna-2014.jpg" alt="Женская трикотажная спортивная кофта" title="Женская трикотажная спортивная кофта" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/plate-iz-trikotaja-vesna-2014.jpg\', width: 509, height: 800, description: \'Женская трикотажная спортивная кофта\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '800,00 руб'
	),
	'856i1ihp' => array(
		'name' => 'Трикотажный спортивный костюм для мужчин',
		'description' => 'Трикотажный спортивный костюм для мужчин',
		'image' => '<img src="images/T2BoNCXnVNXXXXXXXX_--761129123.jpg" alt="Трикотажный спортивный костюм для мужчин" title="Трикотажный спортивный костюм для мужчин" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/T2BoNCXnVNXXXXXXXX_--761129123.jpg\', width: 600, height: 600, description: \'Трикотажный спортивный костюм для мужчин\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '1.100,00 руб'
	),
	'1kb99cu5' => array(
		'name' => 'Нательное трикотажное белье для мужчин',
		'description' => 'Нательное трикотажное белье для мужчин',
		'image' => '<img src="images/110147.jpg" alt="Нательное трикотажное белье для мужчин" title="Нательное трикотажное белье для мужчин" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/110147.jpg\', width: 600, height: 450, description: \'Нательное трикотажное белье для мужчин\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '900,00 руб'
	),
	'rrk5143g' => array(
		'name' => 'Трикотажная футболка защитного цвета',
		'description' => '',
		'image' => '<img src="images/14630594_w640_h640_otazhnaya_kamuflirovannaya.jpg" alt="Трикотажная футболка защитного цвета" title="Трикотажная футболка защитного цвета" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/14630594_w640_h640_otazhnaya_kamuflirovannaya.jpg\', width: 350, height: 525, description: \'\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '400,00 руб'
	),
	'724sjvm1' => array(
		'name' => 'Трикотажный костюм для мужчин',
		'description' => '',
		'image' => '<img src="images/1171404927.jpg" alt="Трикотажный костюм для мужчин" title="Трикотажный костюм для мужчин" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/1171404927.jpg\', width: 223, height: 480, description: \'\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '800,00 руб'
	),
	'rzu6p3f2' => array(
		'name' => 'Нательный костюм для мужчин из трикотажа',
		'description' => 'Нательный костюм для мужчин из трикотажа',
		'image' => '<img src="images/woolly_b.jpg" alt="Нательный костюм для мужчин из трикотажа" title="Нательный костюм для мужчин из трикотажа" onclick="x5engine.imShowBox({media:[{ type: \'image\', url: \'images/woolly_b.jpg\', width: 250, height: 600, description: \'Нательный костюм для мужчин из трикотажа\' }, { type: \'image\', url: \'images/belie_natelnoe_s_nachesom.thumb.jpg\', width: 340, height: 291, description: \'Нательный костюм для мужчин из трикотажа\' }]}, 0, this)" style="cursor: pointer;"/>',
		'price' => '890,00 руб'
	)
);

/*****************
	IMAGES SEARCH
*****************/
$imSettings['search']['images'] = array(
);

/*****************
	VIDEOS SEARCH
*****************/
$imSettings['search']['videos'] = array(
);
$imSettings['search']['dynamicobjects'] = array(
);

// End of file search.inc.php