<?php

// Users data
$imSettings['access']['webregistrations_gid'] = 'w9323381';
$imSettings['access']['users'] = array(
	'admin' => array(
		'groups' => array('7h2691st'),
		'id' => 'ms2s86at',
		'name' => 'Admin',
		'password' => 'o9f9kdzu',
		'email' => '',
		'page' => 'index.html'
	),
	'новый пользователь' => array(
		'groups' => array('ms2s86at'),
		'id' => 'w9323381',
		'name' => 'Новый пользователь',
		'password' => '8uxd0k07',
		'email' => '',
		'page' => 'index.html'
	)
);

// Admins list
$imSettings['access']['admins'] = array('ms2s86at');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php